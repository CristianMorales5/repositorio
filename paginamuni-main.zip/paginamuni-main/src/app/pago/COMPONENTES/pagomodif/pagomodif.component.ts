import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagomodif',
  templateUrl: './pagomodif.component.html',
  styleUrls: ['./pagomodif.component.css']
})
export class PagomodifComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
