import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-turnomodif',
  templateUrl: './turnomodif.component.html',
  styleUrls: ['./turnomodif.component.css']
})
export class TurnomodifComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
