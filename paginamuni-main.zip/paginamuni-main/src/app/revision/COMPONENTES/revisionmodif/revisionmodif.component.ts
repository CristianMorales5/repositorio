import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revisionmodif',
  templateUrl: './revisionmodif.component.html',
  styleUrls: ['./revisionmodif.component.css']
})
export class RevisionmodifComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
