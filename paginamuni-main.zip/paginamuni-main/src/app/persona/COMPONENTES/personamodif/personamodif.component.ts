import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personamodif',
  templateUrl: './personamodif.component.html',
  styleUrls: ['./personamodif.component.css']
})
export class PersonamodifComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
